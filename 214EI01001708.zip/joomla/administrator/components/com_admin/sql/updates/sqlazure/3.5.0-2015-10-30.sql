UPDATE [#__menu] SET [title] = 'com_contact_contacts' WHERE [client_id] = 1 AND [level] = 2 AND [title] = 'com_contact';
