      <hr>

      <p class="text-center">&copy2017 - RichBlog - All Rights Reserved</p>