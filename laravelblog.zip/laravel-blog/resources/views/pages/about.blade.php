@extends('main')

@section('title', '| About')

@section('content')
        <div class="row">
            <div class="col-md-12">
                <h1>About Me</h1>
                <h2><marquee>Here is a bit about me and my blog!</marquee></h2>
                <p>This site was created to basically inform the populace about moi. It is a blog which will be updated from time to time in order to keep its readers or visiters engaged. Feel free to come by often to read the posts. Welcome!</p>
            </div>
        </div>

@endsection
