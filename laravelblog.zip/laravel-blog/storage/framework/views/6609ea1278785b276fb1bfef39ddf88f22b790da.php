<?php $__env->startSection('title', '| About'); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-md-12">
                <h1>About Me</h1>
                <h2><marquee>Here is a bit about me and my blog!</marquee></h2>
                <p>This site was created to basically inform the populace about moi. It is a blog which will be updated from time to time in order to keep its readers or visiters engaged. Feel free to come by often to read the posts. Welcome!</p>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>