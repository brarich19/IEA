<?php $__env->startSection('title', '| Homepage'); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="jumbotron">
                  <h1>Hola, Welcome to My Blog!</h1>
                  <p class="lead"><marquee>This is a simple blog about myself which is still under construction. Come around often to read my posts. GRACIAS!</marquee></p>
                  <p><a class="btn btn-primary btn-lg" href="#" role="button">Popular Post</a></p>
                </div>
            </div>
        </div> <!-- end of header .row -->

        <div class="row">
            <div class="col-md-8">
                
                <?php foreach($posts as $post): ?>

                    <div class="post">
                        <h3><?php echo e($post->title); ?></h3>
                        <p><?php echo e(substr(strip_tags($post->body), 0, 300)); ?><?php echo e(strlen(strip_tags($post->body)) > 300 ? "..." : ""); ?></p>
                        <a href="<?php echo e(url('blog/'.$post->slug)); ?>" class="btn btn-primary">Read More</a>
                    </div>

                    <hr>

                <?php endforeach; ?>

            </div>

            <div class="col-md-3 col-md-offset-1">
                <h1>Sidebar</h1>
                <h3>The following areas and topics will be covered/provided on my blog: </h3>
                <h2>General news<br>Sports<br>Entertainment<br>Fun stuff</h2>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>